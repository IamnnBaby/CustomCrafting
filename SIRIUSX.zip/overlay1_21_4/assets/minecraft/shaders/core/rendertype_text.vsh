#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out mat4x3 texCorners;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    texCorners = mat4x3(0.0);
    switch (gl_VertexID % 4) {
        case 0: texCorners[0] = vec3(UV0.xy, 1.0); break;
        case 1: texCorners[1] = vec3(UV0.xy, 1.0); break;
        case 2: texCorners[2] = vec3(UV0.xy, 1.0); break;
        case 3: texCorners[3] = vec3(UV0.xy, 1.0); break;
    }

    ivec4 markerData = ivec4(texture(Sampler0, texCoord0) * 255.0);

    if (markerData == ivec4(255, 0, 255, 255)) {
        vertexColor = texelFetch(Sampler2, UV2 / 16, 0);
        if (int(Color.r * 255.0) == 1) {
            vertexColor.a = 0;
        }

        int yOffset = int(Color.b * 255.0);
        vec2 onePixel = vec2(ProjMat[0][0], ProjMat[1][1]);
        gl_Position.y = gl_Position.y - (yOffset * onePixel.y);
    }
}
