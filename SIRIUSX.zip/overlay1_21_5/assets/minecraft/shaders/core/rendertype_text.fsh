#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

in mat4x3 texCorners;

const vec2 textureSize = vec2(256.0, 256.0);
const vec2 oneTexel = 1./textureSize;

out vec4 fragColor;

ivec4 getData(vec2 texCoordMax, int x, int y) {
    return ivec4(texture(Sampler0, texCoordMax
        - ((vec2(x, y) - 0.5) * oneTexel)
    ) * 255.0);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

    vec2 texCoordMin = vec2(1.0/0.0);
    vec2 texCoordMax = vec2(-1.0/0.0);
    for (int i = 0; i < 4; i++) {
        if (texCorners[i].z == 0.0) {
            continue;
        }
        vec2 weighted = texCorners[i].xy / texCorners[i].z;
        texCoordMin.x = min(texCoordMin.x, weighted.x);
        texCoordMin.y = min(texCoordMin.y, weighted.y);
        texCoordMax.x = max(texCoordMax.x, weighted.x);
        texCoordMax.y = max(texCoordMax.y, weighted.y);
    }

    ivec4 markerData = getData(texCoordMax, 1, 1);

    if (markerData == ivec4(255, 0, 255, 255)) {
        if (texCoord0.y < (texCoordMin.y + oneTexel.y)) {
            discard;
        } else if (texCoord0.y > (texCoordMax.y - oneTexel.y)) {
            discard;
        }
    }
}
